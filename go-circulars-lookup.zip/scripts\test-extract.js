// Quick test: download the PDF and try text extraction.
import { execSync } from "child_process";
import fs from "fs";
import path from "path";
import os from "os";
import { createRequire } from "module";

const require = createRequire(import.meta.url);
const pdfParse = require("pdf-parse");

const dir = path.join(os.tmpdir(), "drivetest");
const pdfPath = path.join(dir, "gos.pdf");

if (!fs.existsSync(pdfPath)) {
  console.log("Downloading PDF...");
  fs.mkdirSync(dir, { recursive: true });
  execSync(
    `curl -s -L -o "${pdfPath}" "https://drive.usercontent.google.com/download?id=1VkQYDKYbGUoRtdvEMEoThDMCYWpN2gtz&export=download"`,
    { stdio: "inherit", timeout: 300000 }
  );
}

const size = fs.statSync(pdfPath).size;
console.log(`PDF size: ${(size / 1024 / 1024).toFixed(1)} MB`);

console.log("Extracting text (this may take a while for a 59MB PDF)...");
const dataBuffer = fs.readFileSync(pdfPath);
const data = await pdfParse(dataBuffer);

console.log(`Pages: ${data.numpages}`);
console.log(`Total extracted text length: ${data.text.length} chars`);
const sample = data.text.slice(0, 1500).replace(/\s+/g, " ");
console.log("--- First 1500 chars (collapsed whitespace) ---");
console.log(sample);
const cleaned = data.text.replace(/\s+/g, "");
console.log(`Non-whitespace chars: ${cleaned.length}`);
